## ###########################################################################
##
# Utils.py
##
# Author: Etienne Delclaux
# Created: 17/03/2021 11:15:56 2016 (+0200)
##
# Description:
##
## ###########################################################################

from qgis.core import *  # QGIS3

from PyQt5 import QtCore

from pathlib import Path
import csv  
import re
#from io import StringIO  

import typing
from enum import Enum
from .Logger import Logger


class FieldAreaType(str, Enum):
    RURAL = "R"
    URBAN = "U"


class LayersType(str, Enum):
    CENTROIDS = "CENTROIDS"
    CENTROIDS_BUFFERS = "CENTROIDS_BUFFER"
    POLYGONS = "POLYGONS"
    GPS = "GPS"
    MULTIPLT = "MULTIPLT"
    CONVEXHULL = "CONVEXHULL"
    BUFFERSANON = "BUFFERSANON"
    LINKS = "LINKS"
    DISPLACED = "DISPLACED"
    DISPLACEDANON = "DISPLACEDANON"


class LayersName():
    basename = ""
    outputDirectory = ""
    layerNames = {
        LayersType.CENTROIDS: "cluster_centroids",
        LayersType.CENTROIDS_BUFFERS: "cluster_original_centroid_buffers",
        LayersType.POLYGONS: "cluster_polygons",
        LayersType.GPS: "cluster_points",
        LayersType.MULTIPLT: "cluster_multi-points",
        LayersType.CONVEXHULL: "cluster_convex_hulls",
        LayersType.BUFFERSANON: "cluster_anonymised_buffers",
        LayersType.LINKS: "cluster_displacement_links",
        LayersType.DISPLACED: "cluster_unanonymised_displaced_centroids",
        LayersType.DISPLACEDANON: "cluster_anonymised_displaced_centroids",
    }

    @staticmethod
    def layerName(t: LayersType) -> str:
        """ generates layer name for UI
        """
        if LayersName.basename:
            return LayersName.basename + '_' + LayersName.layerNames[t]
        return LayersName.layerNames[t]

    @staticmethod
    def fileName(t: LayersType, ext: str = "shp") -> str:
        """ generates layer name for file
        """
        if LayersName.basename:
            return LayersName.outputDirectory + QtCore.QDir.separator() + LayersName.basename + '_' + LayersName.layerNames[t] + "." + ext
        return LayersName.outputDirectory + QtCore.QDir.separator() + LayersName.layerNames[t] + "." + ext

    @staticmethod
    def customfileName(base: str, ext: str = "shp") -> str:
        """ generates layer name for file
        """
        if LayersName.basename:
            return LayersName.outputDirectory + QtCore.QDir.separator() + LayersName.basename + '_' + base + "." + ext
        return LayersName.outputDirectory + QtCore.QDir.separator() + base + "." + ext

def getLayerByName(name):
    """ Find existing layer with the given name.
    """
    layerList = QgsProject.instance().mapLayersByName(name)
    if layerList:
        return layerList[0]
    return None

def getLayerIfExists(layerType: LayersType) -> QgsMapLayer:
    """ Find existing layer with the given name.
    """
    return getLayerByName(LayersName.layerName(layerType))


def removeLayerIfExistsByName(layerName: str) -> typing.NoReturn:
    """ Remove existing layer with the same name. Avoid duplication when run multiple times.
    """
    layer = getLayerByName(layerName)
    if layer:
        QgsProject.instance().removeMapLayer(layer)

def removeLayerIfExists(layerType: LayersType) -> typing.NoReturn:
    """ Remove existing layer with the same name. Avoid duplication when run multiple times.
    """
    layer = getLayerByName(LayersName.layerName(layerType))
    if layer:
        QgsProject.instance().removeMapLayer(layer)

def putLayerOnTopIfExists(layerType: LayersType) -> typing.NoReturn:
    """ Put layer on top if it exists
    """
    layer = getLayerByName(LayersName.layerName(layerType))
    if layer:
        lyr = QgsProject.instance().takeMapLayer(layer)
        if lyr:
            QgsProject.instance().addMapLayer(lyr)

def createLayer(layerType: str, layerCategorie: LayersType, layerAttributes: typing.List[QgsField]) -> QgsVectorLayer:
    """ Create layer method, given a type, a name and some attributes
    """
    removeLayerIfExists(layerCategorie)

    # error = QgsVectorFileWriter.writeAsVectorFormatV2(layer, "testdata/my_new_shapefile", transform_context, save_options)
    layer = QgsVectorLayer(layerType, LayersName.layerName(layerCategorie), 'memory')
    layer.setCustomProperty("skipMemoryLayersCheck", 1)  # Skip the check when closing qgis !
    provider = layer.dataProvider()
    provider.addAttributes(layerAttributes)
    layer.updateFields()

    return layer


def reloadLayerFromDiskToAvoidMemoryFlag(layerType: LayersType) -> typing.NoReturn:
    """ Close the layer, if it exists. Then reopen it, from the file. To avoid the weird 'memory' flag
    """
    layerName = LayersName.layerName(layerType)
    layer = getLayerByName(layerName)

    # check if the file name is different from the default one (can happen when skipping steps)
    filename = ''
    if layer:
        filename = layer.source()
    if not filename.endswith('.shp'):
        # try default file name
        filename = LayersName.fileName(layerType)

    # print(f"Reloading layer {layerName} from disk: {filename}")
    removeLayerIfExists(layerType)
    layer = QgsVectorLayer(filename, layerName)
    QgsProject.instance().addMapLayer(layer)

def writeLayerIfExists(layerType: LayersType) -> typing.NoReturn:
    """ Write the layer on disk, if it exists in the project instance
    """
    layer = getLayerByName(LayersName.layerName(layerType))
    if layer:
        options = QgsVectorFileWriter.SaveVectorOptions()
        options.driverName = "ESRI Shapefile"

        # writer = QgsVectorFileWriter( "output_path_and_name.shp", provider.encoding(), provider.fields(), QGis.WKBPolygon, provider.crs() )
        writer = QgsVectorFileWriter.writeAsVectorFormatV3(
            layer,
            LayersName.fileName(layerType),
            QgsCoordinateTransformContext(),
            options)
        
        # if writer[0] == QgsVectorFileWriter.NoError:
        #     print("success!")
        # else:
        #     print(writer)

        # Don't know how to manage this.
        # reloadLayerFromDiskToAvoidMemoryFlag(layerType)


def getval(ft: QgsFeature, field: QgsField) -> str:
    """ get value as string from feature / field combo
    """
    if field:
        val = ft[field]
        if val:
            if isinstance(val, basestring):
                # ToDo: decode or encode???: val.encode('UTF-8').strip()
                result = "{}".format(val.encode(
                    'UTF-8').decode('UTF-8').strip())
            else:
                result = "{}".format(val)
        else:
            result = ""
    else:
        result = ""
    return result

def detect_csv_delimiter(file_path, sample_lines=3):
# def detect_csv_delimiter(f, sample_lines=3):
    """Auto-detect CSV delimiter by analyzing first few lines"""

    with open(file_path, 'r', encoding='utf-8-sig') as f:
        sample = ''.join([f.readline() for _ in range(sample_lines)])
    #sample = ''.join([f.readline() for _ in range(sample_lines)])

    sniffer = csv.Sniffer()
    try:
        dialect = sniffer.sniff(sample, delimiters=',;\t\|')
        return dialect.delimiter
    except csv.Error:
        return ','  # fallback to comma
    
def getFieldsListAsStrArray(file: str) -> typing.List[str]:
    """ analyze file and retrieve field list
    """
    fieldList = []
    extension = Path(file).suffix[1:]
    if extension == "shp":
        layer = QgsVectorLayer(file, "tmp", "ogr")
        if layer:
            fieldList = [f.name() for f in layer.fields()]
    elif extension in ["csv", 'tsv', 'txt']:
        delimiter = detect_csv_delimiter(file)
        with open(file, "r") as f:
            fieldList = [s.strip() for s in re.split(re.escape(delimiter), f.readline().strip())] 
    # elif extension == "txt":
    #     with open(file, "r") as f:
    #         line = f.readline()
    #         fieldList = line.strip().split('\t')

    return fieldList

def get_item_index(normalized_candidates, in_list, default=None):
    '''Get the index of the first item in in_list that matches any of the normalized_candidates.
    If default is provided, it will be used if it exists in in_list.'''
    
    index = None

    if default:
        index = in_list.index(default)
    
    # for item in in_list:
    normalized_items = [item.lower().replace(' ', '').replace('_', '') for item in in_list]
    for candidate in normalized_candidates:
        if candidate in normalized_items:
            # If the item is between the candidates, we set it in the combobox
            index = normalized_items.index(candidate)
            break
    
    return index

def setComboBox(combobox, candidates, fields, default=None):
    # print(f"Setting combobox | candidates: {candidates}, fields: {fields}, default: {default}")
    # print(f"Setting combobox | fields: {fields}, default: {default}")
    # print(f"Setting combobox | default: {default}")

    combobox.clear()
    combobox.addItems(fields)
    index = get_item_index(candidates, fields, default)
    # print(f"Determined index: {index}")
    if index is not None:
        # print(f"Setting combobox to index {index}: {fields[index]}")
        combobox.setCurrentIndex(get_item_index(candidates, fields, default))

def layerCrossesTheMeridian(layer: QgsVectorLayer) -> bool:
    """ add a convenient method that checks if a layer crosses the antimeridian
    """
    try:
        ext = layer.extent()
        return ext.xMinimum() == -180 and ext.xMaximum() == 180
    except:
        return False

def getPoleOfInaccessibilityOrCentroid(polygon_feature: QgsFeature, fallback_feature: QgsFeature = None, precision: float = 0.00001) -> typing.NoReturn:
    """ Compute the centroid geometry for a given centroid feature, the multi point and the convexhull
    """

    pole_result = polygon_feature.geometry().poleOfInaccessibility(precision)
    if pole_result[0].isNull(): 
        if fallback_feature:  
            return fallback_feature.geometry().centroid()  # fallback to centroid
        else:
            return polygon_feature.geometry().centroid()  # fallback to centroid  
    else:  
        return pole_result[0]

