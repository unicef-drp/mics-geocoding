## ###########################################################################
##
# mgp_main_widow.py
##
# Author: Etienne Delclaux
# Created: 17/03/2021 11:15:56 2016 (+0200)
##
# Updated: Nazim Gashi
# Time: 06/05/2024 13:00:00
# Time: 08/01/2025 15:00:00 (line 117, 125, and 158 added)
##
# Description:
##
## ###########################################################################


import os

from PyQt5 import QtWidgets, QtCore, QtGui
from pathlib import Path
#from datetime import datetime

#import re
import typing

#from .ui_mgp_mainwindow import Ui_MGPDialog
from .micsgeocode import CentroidBuffersMaxDistanceComputer as Radier
from .micsgeocode import CentroidBuffersLayerWriter as BufferWriter
from .micsgeocode import CentroidsLoader as Loader
from .micsgeocode import Utils
from .micsgeocode.Logger import Logger
#from qgis.core import QgsVectorLayer, QgsProject  # QGIS3


class MGPMainWindowTab1Handler(QtCore.QObject):
    '''The actual window that is displayed in the qgis interface
    '''
    # Define a signal called 'centroidsLoaded'
    centroidsLoaded = QtCore.pyqtSignal()

    def __init__(self, mainwindow):
        """Interface initialisation : display interface and define events"""
        super().__init__()
        self.mainwindow = mainwindow
        self.ui = self.mainwindow.ui

        ## ####################################################################
        # Init signal slots connection
        ## ####################################################################

        self.ui.centroidsSourceFileToolButton.clicked.connect(self.onCentroidsSourceFileToolButtonClicked)
        self.ui.centroidsSourceFileLineEdit.textChanged.connect(self.onCentroidsSourceFileChanged)

        self.ui.longitudeFieldComboBox.currentTextChanged.connect(self.onLongitudeFieldChanged)
        self.ui.latitudeFieldComboBox.currentTextChanged.connect(self.onLatitudeFieldChanged)
        self.ui.numeroFieldComboBox.currentTextChanged.connect(self.onNumeroFieldChanged)
        self.ui.typeFieldComboBox.currentTextChanged.connect(self.onTypeFieldChanged)
        self.ui.adminBoundariesFieldComboBox.currentTextChanged.connect(self.onAdminBoundariesFieldChanged)

        self.ui.loadCentroidsButton.clicked.connect(self.onLoadCentroidsButtonCLicked)
        self.ui.generateCentroidBuffersButton.clicked.connect(self.onGenerateCentroidBuffersButtonCLicked)

        ## ####################################################################
        # Init Tooltips - easier than in qtdesigner
        ## ####################################################################

        self.ui.centroidsSourceFileToolButton.setToolTip("Browse for source file on the computer. Must be CSV file or shapefile (polygon or point layer).")
        self.ui.centroidsSourceFileLineEdit.setToolTip("Cluster source file on the computer.")

        self.ui.numeroFieldComboBox.setToolTip("Choose the field indicating cluster number variable.")
        self.ui.typeFieldComboBox.setToolTip("Choose the field indicating cluster area variable.")
        self.ui.longitudeFieldComboBox.setToolTip("Choose the field indicating longitude. Must be in decimal degree.")
        self.ui.latitudeFieldComboBox.setToolTip("Choose the field indicating latitude. Must be in decimal degree.")
        self.ui.adminBoundariesFieldComboBox.setToolTip("Administrative boundaries. Choose the field indicating administrative boundaries variable of displacement level.")

        self.ui.loadCentroidsButton.setToolTip("Generate Centroids. QGIS generates layers depending on input.")
        self.ui.generateCentroidBuffersButton.setToolTip(
            "Generate Buffers. QGIS generates a buffer layer for the original cluster centroids."
        )

    ## #############################################################
    # reset
    ## #############################################################

    def reset(self) -> typing.NoReturn:
        self.ui.centroidsSourceFileLineEdit.clear()

    # #############################################################
    # Centroids Source
    # #############################################################

    def onCentroidsSourceFileToolButtonClicked(self) -> typing.NoReturn:
        '''Browse for centroid file
        '''
        settings = QtCore.QSettings('MICS Geocode', 'qgis plugin')
        dir = settings.value("last_file_directory", QtCore.QDir.homePath())
        file, _ = QtWidgets.QFileDialog.getOpenFileName(None, "Open cluster source file", dir, "(*.csv *.shp)")
        if file:
            self.centroidsFile = file
            self.ui.centroidsSourceFileLineEdit.setText(os.path.normpath(self.centroidsFile))
            settings.setValue("last_file_directory", os.path.dirname(self.centroidsFile))

    def onCentroidsSourceFileChanged(self) -> typing.NoReturn:
        '''Handle new centroid file
        '''
        # Update manager
        self.updateCentroidCombobox()
        self.mainwindow.updateSaveStatus(True)

    def updateCentroidCombobox(self):
        # Retrieve fieldlist and populate comboboxes
        fields = Utils.getFieldsListAsStrArray(self.ui.centroidsSourceFileLineEdit.text())

        extension = Path(self.ui.centroidsSourceFileLineEdit.text()).suffix[1:]
        self.ui.typeFieldComboBox.clear()
        self.ui.numeroFieldComboBox.clear()
        self.ui.longitudeFieldComboBox.clear()
        self.ui.latitudeFieldComboBox.clear()
        self.ui.adminBoundariesFieldComboBox.clear()

        # init type combobox and look for a default value
        self.ui.typeFieldComboBox.addItems(fields)
        candidates = ["Type", "type", "TYPE", "Area", "HH6"]
        for item in candidates:
            if item in fields:
                self.ui.typeFieldComboBox.setCurrentIndex(fields.index(item))
                break

        # init cluster combobox and look for a default value
        self.ui.numeroFieldComboBox.addItems(fields)
        candidates = ["clusterno", "ClusterNo", "CLUSTERNO", "HH1","Cluster", "CLUSTER", "cluster"]
        for item in candidates:
            if item in fields:
                self.ui.numeroFieldComboBox.setCurrentIndex(fields.index(item))
                break

        # habdle csv vs shp
        if extension == "csv":
            self.ui.longitudeFieldComboBox.setEnabled(True)
            self.ui.latitudeFieldComboBox.setEnabled(True)

            self.ui.longitudeFieldComboBox.addItems(fields)
            self.ui.latitudeFieldComboBox.addItems(fields)

            candidates = ["lat", "Lat", "LAT", "lat.", "Lat.",
                          "LAT.", "latitude", "Latitude", "LATITUDE"]
            for item in candidates:
                if item in fields:
                    self.ui.latitudeFieldComboBox.setCurrentIndex(fields.index(item))
                    break

            candidates = ["lon", "Lon", "LON", "lon.", "Lon.", "LON.", "long", "Long",
                          "LONG", "long.", "Long.", "LONG.", "longitude", "Longitud", "LONGITUDE"]
            for item in candidates:
                if item in fields:
                    self.ui.longitudeFieldComboBox.setCurrentIndex(fields.index(item))
                    break
        else:
            self.ui.longitudeFieldComboBox.setEnabled(False)
            self.ui.latitudeFieldComboBox.setEnabled(False)

        # init cluster combobox and look for a default value
        if fields:
            candidates = ["geonamet", "geonames", "geoname", "micsgeo", "geocodet", "geocodes", "geocode", "hh7a", "district", "lga", "admin", "region", "hh7", "adm1en", "adm1pcode", "adm2en", "adm2pcode"]
            Utils.setComboBox(self.ui.adminBoundariesFieldComboBox, candidates, fields)

    def onLongitudeFieldChanged(self) -> typing.NoReturn:
        '''Update longitude field
        '''
        self.mainwindow.updateSaveStatus(True)

    def onLatitudeFieldChanged(self) -> typing.NoReturn:
        '''Update latitude field
        '''
        self.mainwindow.updateSaveStatus(True)

    def onNumeroFieldChanged(self) -> typing.NoReturn:
        '''Update numero field
        '''
        self.mainwindow.updateSaveStatus(True)

    def onTypeFieldChanged(self) -> typing.NoReturn:
        '''Update type field
        '''
        self.mainwindow.updateSaveStatus(True)

    def onAdminBoundariesFieldChanged(self) -> typing.NoReturn:
        '''Update longitude field
        '''
        self.mainwindow.updateSaveStatus(True)

    ## #############################################################
    # Main actions
    ## #############################################################

    def onLoadCentroidsButtonCLicked(self) -> typing.NoReturn:
        '''Load centroids
        '''
        if not self.ui.centroidsSourceFileLineEdit.text():
            Logger.logWarning("[Generate] A valid cluster source file must be provided")
            return
        else:
            if self.ui.longitudeFieldComboBox.isEnabled() and not self.ui.longitudeFieldComboBox.currentText():
                Logger.logWarning("[Generate] A valid longitude field must be provided")
                return

            if self.ui.latitudeFieldComboBox.isEnabled() and not self.ui.latitudeFieldComboBox.currentText():
                Logger.logWarning("[Generate] A valid latitude field must be provided")
                return

            if self.ui.numeroFieldComboBox.isEnabled() and not self.ui.numeroFieldComboBox.currentText():
                Logger.logWarning("[Generate] A valid numero field must be provided")
                return

            if self.ui.typeFieldComboBox.isEnabled() and not self.ui.typeFieldComboBox.currentText():
                Logger.logWarning("[Generate] A valid type field must be provided")
                return

            if self.ui.adminBoundariesFieldComboBox.isEnabled() and not self.ui.adminBoundariesFieldComboBox.currentText():
                Logger.logWarning("[Generate] A valid admin boundaries field must be provided")
                return

            Logger.logWarning("[Generate] A problem occured while loading centroids")

        try:
            loader = Loader.CentroidsLoader()

            loader.input_file = self.ui.centroidsSourceFileLineEdit.text()

            loader.lon_field = self.ui.longitudeFieldComboBox.currentText()
            loader.lat_field = self.ui.latitudeFieldComboBox.currentText()
            loader.cluster_no_field = self.ui.numeroFieldComboBox.currentText()
            loader.cluster_type_field = self.ui.typeFieldComboBox.currentText()
            loader.admin_boundaries_field = self.ui.adminBoundariesFieldComboBox.currentText()

            loader.loadCentroids()

            Logger.logSuccess("[Generate] Centroids succcessfully generated")

            self.centroidsLoaded.emit()

        except BaseException as e:
            Logger.logException("[Generate] A problem occured while generating centroids.", e)

    def onGenerateCentroidBuffersButtonCLicked(self) -> typing.NoReturn:
        Logger.logInfo("[Generate] About to generate")

        centroidLayer = Utils.getLayerIfExists(Utils.LayersType.CENTROIDS)

        if not centroidLayer:
            Logger.logWarning("[Generate] A valid centroid source file must be generated first.")
            return
        
        #Get the max distances per buffer id
        radier = Radier.CentroidBuffersMaxDistanceComputer()
        radier.centroidLayer = centroidLayer
        radier.computeBufferRadiusesCentroids()
        maxDistances = radier.maxDistance

        if not maxDistances:
            Logger.logWarning("[Generate] The displacement has not been computed. The centroids buffer layer can't be generated.")
            return

        try:
            bufferer = BufferWriter.CentroidBuffersLayerWriter()
            bufferer.maxDistances = maxDistances
            bufferer.writerCentroidBuffersLayer()

        except:
            Logger.logWarning("[Generate] A problem occured while generating centroids buffer.")
